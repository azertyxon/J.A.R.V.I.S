function handleCommand() {
    const input = document.getElementById('commandInput').value.toLowerCase();
    alert('Commande reçue : ' + input);
}